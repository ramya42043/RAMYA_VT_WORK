#! /bin/bash
export LD_LIBRARY_PATH=$(pwd)/Executables/${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
