#include<stdio.h>
void main(void)
{
	unsigned int n;
	printf("Enter number: ");
	scanf("%u",&n);
	for(int i = 0,j=(sizeof(unsigned int)*8) - 1; i<=j ;i++,j--)
	{
		if(n&(1<<j)^n&(1<<i))
		{
			n = n^(1<<j);
			n = n^(1<<i);
			
		}
	}
	printf("value %u\n",n);
}
