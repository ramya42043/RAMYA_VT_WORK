#include<stdio.h>
int main(void)
{
	if(printf("Hello") == 0)
		;
	else
	   printf("World");
}
