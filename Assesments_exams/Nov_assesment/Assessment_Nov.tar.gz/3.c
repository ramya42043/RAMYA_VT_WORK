#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
	int val;
	struct node * left;
	struct node * right;
}NODE;
NODE * Main_head =NULL;
void print(NODE *list)
{
	while(list != NULL)
	{
		printf("%d ", list->val);
		if(list->left != NULL)
			printf("%d ", list->val);
		list = list->next;
	}
}

NODE *add(NODE *list, int value,int lr)
{
	NODE *temp=list;
	if(list == NULL)
	{
	NODE *temp;
	temp = malloc(sizeof(NODE*));
	temp->val = value;
	temp->left = NULL;
	temp->right = NULL;
	return temp;	
	}
	if(lr==0 && list->left==NULL)
	{
		NODE *temp1;
		temp1 = malloc(sizeof(NODE*));
		temp1->val = value;
		temp1->left = NULL;
		temp1->right = NULL;
		list->left=temp1;
	}
	if(lr==1 && list->right==NULL)
	{
		NODE *temp1;
		temp1 = malloc(sizeof(NODE*));
		temp1->val = value;
		temp1->left = NULL;
		temp1->right = NULL;
		list->right=temp1;
	}	
	if(temp != NULL && temp->val >value)
	{
		if(temp->left != NULL)
			add(temp->left,value,0);
		else
			add(temp,value,0);
		if(temp != NULL && temp->val < value)
			if(temp->right != NULL)
				add(temp->right,value,1);
		else
			add(temp,value,1);		
	}	
	return list;	
}
int main()
{

	
}
