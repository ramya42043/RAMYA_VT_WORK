#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
	int val;
	struct node * next;
}NODE;
void print(NODE *list)
{
	while(list != NULL)
	{
		printf("%d->", list->val);
		list = list->next;
	}
}
NODE * add(NODE *list,int value)
{
	NODE *head=list,*temp;
	temp = malloc(sizeof(NODE*));
	temp->val = value;
	temp->next = NULL;
	if(head == NULL)
	{
		head=temp;
		return head;
	}
	else
	{
		while(head->next != NULL)
			head = head->next;
		head->next = temp;
	}
	return list;
}
void reverse(NODE* head)
{
    if(head!=NULL)
	reverse(head->next);
    else
	return;
    printf("->%d",head->val);

}

int main()
{
	NODE *Head=NULL;
	Head=add(Head,1);
	Head=add(Head,2);
	Head=add(Head,3);
	Head=add(Head,4);
	print(Head);
	printf("\n");
	reverse(Head);
	printf("\n");
	//reverse(Head);
}
