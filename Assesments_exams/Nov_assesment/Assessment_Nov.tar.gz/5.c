#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
	int val;
	struct node * next;
}NODE;
int count = 0;
void print(NODE *list)
{
	while(list != NULL)
	{
		printf("%d->", list->val);
		list = list->next;
	}
}
NODE * add(NODE *list,int value)
{
	NODE *head=list,*temp;
	temp = malloc(sizeof(NODE*));
	temp->val = value;
	temp->next = NULL;
	if(head == NULL)
	{
		head=temp;
		count++;
		return head;
	}
	else
	{
		while(head->next != NULL)
			head = head->next;
		head->next = temp;
		count++;
	}
	return list;
}
void printNLast(NODE * head, int n)
{
	NODE *temp=head;
	if(n>count)
	{
		printf("Number is out of range\n");
		return;
	}
	int m = n;
	while(m>0)
	{
		if(temp!=NULL)
			temp=temp->next;
		m--;
	}
	while(temp != NULL)
	{
		head=head->next;
		temp=temp->next;
		m++;
	}
	printf("%dth node value from last is %d\n",n,head->val);
}

int main()
{
	int n=0;
	NODE *Head=NULL;
	Head=add(Head,1);
	Head=add(Head,2);
	Head=add(Head,3);
	Head=add(Head,4);
	Head=add(Head,5);
	Head=add(Head,6);
	print(Head);
	printf("\n");
	printf("Enter Number to print value from last: ");
	scanf("%d", &n);
	printNLast(Head,n);

}
