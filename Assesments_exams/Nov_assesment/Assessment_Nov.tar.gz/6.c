#include<stdio.h>
#include<string.h>
void print(char *str, int i)
{
	printf("%c",str[i]);
}
void possiblePrints(char * str, int g)
{

	{
		for(int i =0;i<strlen(str);i++)
		if(g>=0)
		{
			for(int j=0;j<strlen(str);j++)
			if(g>=1)
			{
				for(int k=0; k<strlen(str);k++)
				if(g>=2)
				{
					printf("%c%c%c ", str[i],str[j],str[k]);
				}
			}
			else
			{
				printf("%c%c ",str[i],str[j]);
			}
		}
		else
			printf("%c ",str[i]);
	}	
	printf("\n");
}
int main(void)
{
	char dial[12][5]={"0","1","abc", "def", "ghi", "jkl", "mno", "pqrs","tuv","wxyz"};
	char a[10], str[26]={'\0'};
	int test=0, g=0;
	printf("Enter number of test cases:");
	scanf("%d", &test);
	printf("Grouping:");
	scanf("%d", &g);
	printf("dial number from 0 to 9: ");
	scanf("%s", a);
	for(int i =0 ;i<strlen(a);i++)
	{
		if(a[i]-48 != 0 && a[i]-48 != 1)
		strcpy(str+strlen(str),dial[a[i]-48]);
	}
	printf("string %s\n", str);
	if(g>3)
		g=3;
	while(test--)
	{
		possiblePrints(str,g-1);
	}
}
